SODAH GMAIL INBOX OAUTH FIX

Included files:
1. lib/inbox-email-ai.js
   - Gmail OAuth client uses refresh_token.
   - Automatically refreshes expired access tokens.
   - Persists refreshed access/refresh tokens safely.

2. app/api/inbox-email-ai/google/callback/route.js
   - Preserves the existing refresh token when Google does not return a new one.
   - Saves the valid refresh token with the Gmail connection.

3. app/api/inbox-email-ai/messages/route.js
   - Separates revoked/invalid OAuth credentials from normal Gmail permission errors.
   - Returns GMAIL_REAUTH_REQUIRED when reauthorization is actually needed.

IMPORTANT:
After replacing these files, reconnect Gmail once so the current connection has a valid
refresh token. Normal access-token expiry should then be handled automatically.
