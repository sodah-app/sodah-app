"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

const templates = [
  ["promotion", "Promotion", "Promote an offer, service, product, or special deal."],
  ["followup", "Follow-up", "Follow up with a lead or customer naturally."],
  ["appointment", "Appointment", "Invite, confirm, or remind someone about an appointment."],
  ["introduction", "Introduction", "Introduce your business to a potential customer."],
  ["announcement", "Announcement", "Share an important business update."],
  ["thankyou", "Thank you", "Send a genuine customer thank-you email."],
];

export default function EmailAIPage() {
  const [account, setAccount] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState(false);
  const [busyDelete, setBusyDelete] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [templateKey, setTemplateKey] = useState("promotion");
  const [instruction, setInstruction] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [recipients, setRecipients] = useState("");
  const [showComposer, setShowComposer] = useState(false);

  const token = useCallback(async () => {
    const { data, error } = await supabase.auth.getSession();
    if (error || !data?.session?.access_token) {
      throw new Error("Your session has expired. Please sign in again.");
    }
    return data.session.access_token;
  }, []);

  const api = useCallback(async (url, options = {}) => {
    const t = await token();
    const response = await fetch(url, {
      ...options,
      headers: {
        ...(options.headers || {}),
        Authorization: `Bearer ${t}`,
      },
      cache: "no-store",
    });

    const data = await response.json();

    if (!response.ok || !data?.success) {
      throw new Error(data?.message || "Request failed.");
    }

    return data;
  }, [token]);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError("");
      const [accountData, historyData] = await Promise.all([
        api("/api/email-ai/account"),
        api("/api/email-ai/history"),
      ]);
      setAccount(accountData.account);
      setHistory(historyData.history || []);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [api]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("connected") === "1") {
      setNotice("Gmail connected successfully.");
      load();
      window.history.replaceState({}, "", "/email-ai");
    }
    if (params.get("error")) {
      setError(params.get("error"));
      window.history.replaceState({}, "", "/email-ai");
    }
  }, [load]);

  const connectGmail = async () => {
    try {
      setConnecting(true);
      setError("");
      const data = await api("/api/email-ai/google/connect");
      window.location.href = data.url;
    } catch (e) {
      setError(e.message);
      setConnecting(false);
    }
  };

  const disconnect = async () => {
    if (!window.confirm("Disconnect this Gmail account from Sodah?")) return;

    try {
      await api("/api/email-ai/account", { method: "DELETE" });
      setAccount(null);
      setNotice("Gmail disconnected.");
    } catch (e) {
      setError(e.message);
    }
  };

  const generate = async () => {
    try {
      setGenerating(true);
      setError("");
      setNotice("");

      const data = await api("/api/email-ai/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          templateKey,
          instruction,
          businessName: account?.gmail_name || "your business",
        }),
      });

      setSubject(data.subject);
      setMessage(data.body);
      setShowComposer(true);
      setNotice("AI prepared your email. Review it before sending.");
    } catch (e) {
      setError(e.message);
    } finally {
      setGenerating(false);
    }
  };

  const parsedRecipients = useMemo(
    () =>
      [...new Set(
        recipients
          .split(/[\n,;]+/)
          .map((x) => x.trim())
          .filter(Boolean)
      )],
    [recipients]
  );

  const send = async () => {
    try {
      if (!account) throw new Error("Connect Gmail before sending.");
      if (!subject.trim()) throw new Error("Add an email subject.");
      if (!message.trim()) throw new Error("Add an email message.");
      if (!parsedRecipients.length) throw new Error("Paste at least one Gmail address.");

      setSending(true);
      setError("");
      setNotice("");

      const data = await api("/api/email-ai/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject,
          message,
          recipients: parsedRecipients,
          templateKey,
          title: subject,
        }),
      });

      setNotice(data.message);
      setHistory((x) => [data.history, ...x]);
      setRecipients("");
    } catch (e) {
      setError(e.message);
    } finally {
      setSending(false);
    }
  };

  const reuse = (item) => {
    setTemplateKey(item.template_key || "promotion");
    setSubject(item.subject || "");
    setMessage(item.body || "");
    setRecipients((item.recipients || []).join("\n"));
    setShowComposer(true);
    setNotice("Previous email loaded. You can edit and reuse it.");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const removeHistory = async (id) => {
    if (!window.confirm("Permanently delete this email from history?")) return;

    try {
      setBusyDelete(id);
      await api(`/api/email-ai/history?id=${encodeURIComponent(id)}`, {
        method: "DELETE",
      });
      setHistory((x) => x.filter((item) => item.id !== id));
      setNotice("Email history permanently deleted.");
    } catch (e) {
      setError(e.message);
    } finally {
      setBusyDelete("");
    }
  };

  return (
    <main className="page">
      <div className="shell">
        <header className="hero">
          <div>
            <div className="eyebrow"><i /> SODAH EMAIL AI</div>
            <h1>AI-powered email<br /><span>that sounds like you.</span></h1>
            <p>Create, prepare and send professional emails directly from your connected Gmail.</p>
          </div>
          <button className="connect" onClick={connectGmail} disabled={connecting}>
            {connecting ? "Connecting…" : account ? "Reconnect Gmail" : "＋ Connect Gmail"}
          </button>
        </header>

        {(notice || error) && <div className={error ? "notice error" : "notice"}>{error || notice}</div>}

        <section className="stats">
          <div><small>GMAIL</small><strong>{account ? "1" : "0"}</strong><span>{account?.gmail_email || "Not connected"}</span></div>
          <div><small>EMAILS SENT</small><strong>{history.reduce((n, x) => n + Number(x.sent_count || 0), 0)}</strong><span>Total from Sodah</span></div>
          <div><small>CAMPAIGNS</small><strong>{history.length}</strong><span>Saved email history</span></div>
          <div><small>STATUS</small><strong className={account ? "green" : ""}>{account ? "ON" : "OFF"}</strong><span>{account ? "Gmail connected" : "Connect Gmail"}</span></div>
        </section>

        <section className="workspace">
          <div className="connection-card">
            <div className="card-title">
              <div className="gmail-icon">G</div>
              <div><small>CONNECTED GMAIL</small><h2>{account ? account.gmail_email : "Connect your Gmail"}</h2></div>
            </div>
            {account ? (
              <>
                <div className="connected-line"><b>✓</b> Google account connected securely</div>
                <button className="outline" onClick={disconnect}>Disconnect Gmail</button>
              </>
            ) : (
              <>
                <p>Connect the Gmail account you want Sodah to send from.</p>
                <button className="connect wide" onClick={connectGmail}>📧 Connect Gmail</button>
              </>
            )}
          </div>

          <div className="ai-card">
            <div className="spark">✦</div>
            <small>AI EMAIL WRITER</small>
            <h2>What do you want to send?</h2>
            <p>Choose a starting template or tell the AI exactly what you want.</p>

            <div className="templates">
              {templates.map(([key, name, desc]) => (
                <button key={key} className={templateKey === key ? "template active" : "template"} onClick={() => setTemplateKey(key)}>
                  <b>{name}</b><span>{desc}</span>
                </button>
              ))}
            </div>

            <textarea
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
              placeholder="Example: Tell customers about our September offer and invite them to contact us on WhatsApp…"
            />

            <button className="generate" disabled={!account || generating} onClick={generate}>
              {generating ? "Preparing your email…" : "✦ Generate with AI"}
            </button>
          </div>
        </section>

        <section className={`composer ${showComposer ? "open" : ""}`}>
          <div className="section-head"><div><small>READY TO SEND</small><h2>Send email</h2><p>Review the AI message, edit it if you want, then paste your recipients.</p></div></div>

          <div className="form-grid">
            <div>
              <label>From</label>
              <div className="from">{account ? `✓ ${account.gmail_email}` : "Connect Gmail first"}</div>
            </div>
            <div>
              <label>Recipients</label>
              <textarea value={recipients} onChange={(e) => setRecipients(e.target.value)} placeholder={"Paste Gmail addresses here\none per line, or separated by commas"} />
              <div className="count">{parsedRecipients.length} recipient{parsedRecipients.length === 1 ? "" : "s"}</div>
            </div>
          </div>

          <label>Subject</label>
          <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Email subject" />

          <label>Message</label>
          <textarea className="message" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Your email will appear here…" />

          <div className="composer-actions">
            <button className="outline" onClick={() => setShowComposer(false)}>Close</button>
            <button className="send" disabled={!account || sending} onClick={send}>{sending ? "Sending…" : "Send Email →"}</button>
          </div>
        </section>

        <section className="history">
          <div className="section-head">
            <div><small>YOUR EMAILS</small><h2>History</h2><p>Reuse previous emails or permanently delete them.</p></div>
            <strong>{history.length}</strong>
          </div>

          {loading ? <div className="empty">Loading history…</div> : history.length === 0 ? (
            <div className="empty">Your sent email history will appear here.</div>
          ) : (
            <div className="history-list">
              {history.map((item) => (
                <article className="history-item" key={item.id}>
                  <div className="history-main">
                    <div className="history-icon">✉</div>
                    <div><h3>{item.subject}</h3><p>{item.sent_count} sent · {item.failed_count} failed · {new Date(item.created_at).toLocaleString()}</p></div>
                  </div>
                  <div className="history-actions">
                    <button onClick={() => reuse(item)}>Reuse</button>
                    <button className="delete" disabled={busyDelete === item.id} onClick={() => removeHistory(item.id)}>{busyDelete === item.id ? "Deleting…" : "Delete"}</button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>

      <style jsx>{`
        .page{min-height:100%;background:radial-gradient(circle at 10% 0%,rgba(74,222,128,.07),transparent 27%),radial-gradient(circle at 90% 15%,rgba(99,102,241,.06),transparent 25%),#020617;color:#f8fafc;font-family:Inter,ui-sans-serif,system-ui,sans-serif}.shell{max-width:1180px;margin:auto;padding:32px 28px 60px}.hero{display:flex;align-items:flex-end;justify-content:space-between;gap:30px;padding:25px 0 32px;border-bottom:1px solid #ffffff12}.eyebrow{color:#86efac;font-size:10px;font-weight:900;letter-spacing:.18em}.eyebrow i{display:inline-block;width:6px;height:6px;border-radius:50%;background:#4ade80;margin-right:8px}.hero h1{font-size:clamp(32px,4vw,52px);line-height:1;letter-spacing:-.05em;margin:13px 0}.hero h1 span{color:#86efac}.hero p{max-width:620px;color:#94a3b8;font-size:14px;line-height:1.7}.connect,.generate,.send{min-height:44px;padding:0 17px;border-radius:11px;border:1px solid #4ade8040;background:linear-gradient(135deg,#4ade80,#22c55e);color:#052e16;font-weight:900;font-size:12px;cursor:pointer}.connect:disabled,.generate:disabled,.send:disabled{opacity:.45;cursor:not-allowed}.wide{width:100%;margin-top:14px}.notice{margin:20px 0;padding:12px 14px;border-radius:11px;background:#4ade8008;border:1px solid #4ade8028;color:#bbf7d0;font-size:12px}.notice.error{background:#f8717108;border-color:#f8717130;color:#fecaca}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:22px 0}.stats>div,.connection-card,.ai-card,.composer,.history{border:1px solid #ffffff10;background:linear-gradient(145deg,#0f172acc,#020617e8);border-radius:17px}.stats>div{padding:17px}.stats small,.card-title small,.ai-card>small,.section-head small{display:block;color:#64748b;font-size:9px;font-weight:900;letter-spacing:.14em}.stats strong{display:block;font-size:28px;margin:8px 0 3px}.stats strong.green{color:#86efac}.stats span{color:#64748b;font-size:10px}.workspace{display:grid;grid-template-columns:.9fr 1.4fr;gap:13px}.connection-card,.ai-card{padding:21px}.card-title{display:flex;align-items:center;gap:12px}.gmail-icon{width:44px;height:44px;border-radius:13px;background:#ffffff08;border:1px solid #ffffff12;display:flex;align-items:center;justify-content:center;color:#fca5a5;font-weight:900}.card-title h2{font-size:16px;margin:5px 0 0}.connection-card p,.ai-card>p{color:#64748b;font-size:11px;line-height:1.6}.connected-line{margin:19px 0;color:#86efac;font-size:11px}.connected-line b{margin-right:7px}.outline{min-height:39px;padding:0 13px;border-radius:9px;border:1px solid #ffffff14;background:#0f172a;color:#cbd5e1;font-size:10px;font-weight:800;cursor:pointer}.ai-card h2{font-size:22px;margin:7px 0}.spark{color:#86efac;font-size:21px}.templates{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin:15px 0}.template{text-align:left;padding:10px;border-radius:9px;border:1px solid #ffffff0e;background:#0f172a;color:#cbd5e1;cursor:pointer}.template.active{border-color:#4ade8040;background:#4ade8008}.template b{display:block;font-size:10px}.template span{display:block;color:#64748b;font-size:8px;line-height:1.4;margin-top:3px}.ai-card textarea,.composer textarea,.composer input{box-sizing:border-box;width:100%;border:1px solid #ffffff12;background:#020617;color:#f8fafc;border-radius:10px;outline:none;padding:11px;font:inherit;font-size:11px}.ai-card textarea{height:82px;resize:vertical}.generate{width:100%;margin-top:9px}.composer{margin-top:13px;padding:22px}.composer:not(.open){opacity:.55}.section-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:17px}.section-head h2{font-size:19px;margin:6px 0 4px}.section-head p{margin:0;color:#64748b;font-size:10px}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.composer label{display:block;color:#94a3b8;font-size:10px;font-weight:800;margin:12px 0 6px}.from{min-height:42px;box-sizing:border-box;padding:12px;border-radius:10px;border:1px solid #ffffff10;background:#0f172a;color:#86efac;font-size:11px}.form-grid textarea{height:100px;resize:vertical}.composer input{height:43px}.composer .message{height:180px;resize:vertical}.count{color:#475569;text-align:right;font-size:9px;margin-top:4px}.composer-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:17px}.history{margin-top:13px;padding:22px}.history .section-head>strong{padding:7px 10px;border-radius:8px;background:#0f172a;color:#cbd5e1;font-size:10px}.history-list{display:grid;gap:8px}.history-item{display:flex;align-items:center;justify-content:space-between;gap:15px;padding:14px;border:1px solid #ffffff0d;background:#ffffff03;border-radius:11px}.history-main{display:flex;align-items:center;gap:11px;min-width:0}.history-icon{width:34px;height:34px;display:flex;align-items:center;justify-content:center;border-radius:9px;background:#4ade8008;color:#86efac}.history-main h3{margin:0 0 4px;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.history-main p{margin:0;color:#64748b;font-size:9px}.history-actions{display:flex;gap:7px;flex-shrink:0}.history-actions button{min-height:32px;padding:0 10px;border-radius:8px;border:1px solid #ffffff12;background:#0f172a;color:#cbd5e1;font-size:9px;font-weight:800;cursor:pointer}.history-actions .delete{color:#fca5a5}.history-actions button:disabled{opacity:.5}.empty{padding:45px;text-align:center;color:#64748b;font-size:11px;border:1px solid #ffffff0d;border-radius:11px}@media(max-width:850px){.hero{align-items:flex-start;flex-direction:column}.connect{width:100%}.stats{grid-template-columns:1fr 1fr}.workspace{grid-template-columns:1fr}.templates{grid-template-columns:1fr 1fr}.form-grid{grid-template-columns:1fr}}@media(max-width:520px){.shell{padding:20px 15px 40px}.stats{grid-template-columns:1fr}.templates{grid-template-columns:1fr}.history-item{align-items:flex-start;flex-direction:column}.history-actions{width:100%}.history-actions button{flex:1}}
      `}</style>
    </main>
  );
}
