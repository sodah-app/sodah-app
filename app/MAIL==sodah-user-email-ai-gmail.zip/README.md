# Sodah User Email AI — Gmail Edition

🔵 USER PLATFORM ONLY

This is a fresh User Platform email system based on the Email AI format requested for Sodah.

## Current scope

One Gmail account per business for the first version.

User flow:

1. Open Email AI
2. Click Connect Gmail
3. Google authorization opens
4. User chooses the Gmail account
5. User approves Sodah
6. Gmail returns to Sodah
7. User writes a campaign manually OR chooses an AI template
8. AI prepares the subject and email body
9. User pastes recipient Gmail addresses
10. User reviews and sends
11. Sent email is stored in history
12. A previous email can be reused or permanently deleted

## Included

- Premium Email AI dashboard
- One Gmail connection per business
- Google OAuth
- Secure encrypted Gmail refresh-token storage
- Gmail API sending
- AI email generation endpoint
- AI templates
- Manual prompt generation
- Recipient paste box
- Review before sending
- Sent history
- Reuse history
- Permanent history deletion
- Business/tenant isolation

## Install

npm install googleapis

The package assumes the existing Sodah User Platform already has:
- Next.js App Router
- `@/lib/supabase`
- Supabase authentication

## Environment variables

USER PLATFORM `.env.local`:

NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...

GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REDIRECT_URI=https://YOUR-DOMAIN.com/api/email-ai/google/callback

EMAIL_TOKEN_ENCRYPTION_KEY=...

OPENAI_API_KEY=...
OPENAI_MODEL=gpt-4.1-mini

Generate the encryption key:

node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

## Google Cloud setup

Create a Google OAuth Web Application.

Authorized redirect URI:

https://YOUR-DOMAIN.com/api/email-ai/google/callback

Scopes used:

https://www.googleapis.com/auth/gmail.send
https://www.googleapis.com/auth/userinfo.email

For production, configure the OAuth consent screen and publish/verify the app as required by Google.

## Database

Run:

supabase/email_ai_schema.sql

## Files

app/email-ai/page.jsx
app/api/email-ai/google/connect/route.js
app/api/email-ai/google/callback/route.js
app/api/email-ai/account/route.js
app/api/email-ai/send/route.js
app/api/email-ai/history/route.js
app/api/email-ai/generate/route.js
lib/email-ai.js
supabase/email_ai_schema.sql

## Navigation

Add an Email AI link to the existing User Platform navigation:

/email-ai

## Important

The system does not bypass Gmail sending limits or anti-spam rules.

"Unlimited" means Sodah does not impose an artificial monthly quota. Gmail's own sending limits and policies still apply.

The first version intentionally supports one Gmail connection per business. The database can be expanded to multiple Gmail accounts later.
