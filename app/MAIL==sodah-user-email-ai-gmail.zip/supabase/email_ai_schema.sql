-- 🔵 USER PLATFORM ONLY
-- Email AI Gmail system.
-- Does not touch the existing Admin Email Campaign tables.

create extension if not exists pgcrypto;

create table if not exists public.email_ai_gmail_accounts (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null,
  gmail_email text not null,
  gmail_name text,
  google_sub text,
  access_token_encrypted text,
  refresh_token_encrypted text not null,
  token_expires_at timestamptz,
  is_connected boolean not null default true,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists email_ai_gmail_one_per_business
  on public.email_ai_gmail_accounts(business_id);

create index if not exists email_ai_gmail_user_idx
  on public.email_ai_gmail_accounts(user_id);

create table if not exists public.email_ai_history (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null,
  gmail_account_id uuid references public.email_ai_gmail_accounts(id) on delete set null,
  template_key text,
  title text,
  subject text not null,
  body text not null,
  recipients text[] not null default '{}',
  sent_count integer not null default 0,
  failed_count integer not null default 0,
  status text not null default 'sent',
  created_at timestamptz not null default now()
);

create index if not exists email_ai_history_business_idx
  on public.email_ai_history(business_id, created_at desc);

alter table public.email_ai_gmail_accounts enable row level security;
alter table public.email_ai_history enable row level security;

-- All writes/reads in the included API routes use the service role
-- after authenticating the Supabase access token.
